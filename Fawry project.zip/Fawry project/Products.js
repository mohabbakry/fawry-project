document.addEventListener("DOMContentLoaded", function () {
  // 1. Show welcome message
  alert("Welcome to Nike Products Page!");

  // 2. Handle Buy Now button clicks
  const buyButtons = document.querySelectorAll(".btn-primary");
  buyButtons.forEach(function (btn) {
    btn.addEventListener("click", function (e) {
      e.preventDefault(); // Prevent actual link if needed
      alert("Product added to cart!");
    });
  });

  // 3. Add hover effect to cards (optional JS version)
  const cards = document.querySelectorAll(".card");
  cards.forEach(function (card) {
    card.addEventListener("mouseenter", function () {
      card.style.boxShadow = "0 12px 30px rgba(0, 0, 0, 0.25)";
    });
    card.addEventListener("mouseleave", function () {
      card.style.boxShadow = "0 10px 25px rgba(0, 0, 0, 0.2)";
    });
  });
});
