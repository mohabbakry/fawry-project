window.onload = function () {
  alert("Welcome to Nike Store!");
};


document.addEventListener("DOMContentLoaded", function () {
  const shopButton = document.querySelector(".btn-primary");
  if (shopButton) {
    shopButton.addEventListener("click", function () {
      alert("Taking you to our Products...");
    });
  }


  const carousel = document.querySelector(".carousel-inner");
  if (carousel) {
    carousel.addEventListener("mouseover", function () {
      document.body.style.backgroundColor = "#e9ecef";
    });

    carousel.addEventListener("mouseout", function () {
      document.body.style.backgroundColor = "#f8f9fa";
    });
  }
});


document.addEventListener("DOMContentLoaded", function () {
  const toggleBtn = document.getElementById("darkModeToggle");

  toggleBtn.addEventListener("click", function () {
    document.body.classList.toggle("dark-mode");


    if (document.body.classList.contains("dark-mode")) {
      toggleBtn.innerHTML = "☀️ Light Mode";
    } else {
      toggleBtn.innerHTML = "🌙 Dark Mode";
    }
  });
});
