document.addEventListener("DOMContentLoaded", function () {
  const button = document.getElementById("openPdfBtn");

  button.addEventListener("click", function () {
    // افتح ملف الـ PDF الموجود في نفس المجلد
    window.open("book.pdf", "_blank");
  });
});
