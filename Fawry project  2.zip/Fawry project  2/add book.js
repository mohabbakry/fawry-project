document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("bookForm");
  const tableBody = document.getElementById("bookTableBody");

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const title = document.getElementById("title").value;
    const author = document.getElementById("author").value;
    const isbn = document.getElementById("isbn").value;
    const email = document.getElementById("email").value;

    // إنشاء صف جديد
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${title}</td>
      <td>${author}</td>
      <td>${isbn}</td>
      <td>${email}</td>
      <td><button class="btn btn-danger btn-sm remove-btn">Delete</button></td>
    `;

    tableBody.appendChild(row);

    // إعادة تعيين النموذج
    form.reset();
  });

  // حذف صف من الجدول
  tableBody.addEventListener("click", function (e) {
    if (e.target.classList.contains("remove-btn")) {
      e.target.closest("tr").remove();
    }
  });
});
