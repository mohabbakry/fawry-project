document.addEventListener("DOMContentLoaded", function () {
  // 1. Show welcome message
  alert("You can get any book from Quantum Bookstore! thank you sir");

  // 2. Handle Buy Now button clicks
  const buyButtons = document.querySelectorAll(".btn-primary");
  buyButtons.forEach(function (btn) {
    btn.addEventListener("click", function (e) {
      e.preventDefault(); // Prevent actual link if needed
      alert("The file will open");
    });
  });

  // 3. Add hover effect to cards (optional JS version)
  const cards = document.querySelectorAll(".card");
  cards.forEach(function (card) {
    card.addEventListener("mouseenter", function () {
      card.style.boxShadow = "0 12px 30px rgba(0, 0, 0, 0.25)";
    });
    card.addEventListener("mouseleave", function () {
      card.style.boxShadow = "0 10px 25px rgba(0, 0, 0, 0.2)";
    });
  });
});

// تحميل السلة من localStorage أو إنشاء سلة جديدة
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// لما الصفحة تخلص تحميل
document.addEventListener("DOMContentLoaded", function () {
  const addToCartButtons = document.querySelectorAll('.add-to-cart-btn');

  addToCartButtons.forEach(button => {
    button.addEventListener('click', () => {
      const id = button.getAttribute('data-id');
      const title = button.getAttribute('data-title');
      const price = parseFloat(button.getAttribute('data-price'));

      // لو المنتج موجود في السلة زود الكمية
      const existing = cart.find(item => item.id === id);

      if (existing) {
        existing.quantity += 1;
      } else {
        cart.push({ id, title, price, quantity: 1 });
      }

      // حفظ السلة في localStorage
      localStorage.setItem('cart', JSON.stringify(cart));

      alert(`${title} has been added to your cart!`);

      // تحديث العداد في الزرار لو موجود
      updateCartCount();
    });
  });

  // تحديث عدد المنتجات في الزرار اللي في الـ Navbar
  updateCartCount();
});

// دالة لتحديث عدد المنتجات في Navbar
function updateCartCount() {
  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
  const countSpan = document.getElementById('cart-count');
  if (countSpan) {
    countSpan.textContent = cartCount;
  }
}

document.getElementById("openPdfBtn").addEventListener("click", function () {
  window.open("file.pdf", "_blank");
});
