document.addEventListener("DOMContentLoaded", () => {
  const cartTable = document.getElementById("cartItems");
  const totalPriceElement = document.getElementById("totalPrice");
  const clearCartBtn = document.getElementById("clearCart");

  let cart = JSON.parse(localStorage.getItem('cart')) || [];

  function renderCart() {
    cartTable.innerHTML = "";
    let total = 0;

    cart.forEach((item, index) => {
      const subtotal = item.price * item.quantity;
      total += subtotal;

      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${item.title}</td>
        <td>${item.price.toFixed(2)} EGP</td>
        <td>${item.quantity}</td>
        <td>${subtotal.toFixed(2)} EGP</td>
        <td>
          <button class="btn btn-sm btn-danger remove-btn" data-index="${index}">
            Remove
          </button>
        </td>
      `;
      cartTable.appendChild(row);
    });

    totalPriceElement.textContent = total.toFixed(2);
  }

  // حذف منتج واحد
  cartTable.addEventListener("click", (e) => {
    if (e.target.classList.contains("remove-btn")) {
      const index = e.target.getAttribute("data-index");
      cart.splice(index, 1);
      localStorage.setItem("cart", JSON.stringify(cart));
      renderCart();
    }
  });

  // حذف كل المنتجات
  clearCartBtn.addEventListener("click", () => {
    if (confirm("Are you sure you want to clear the cart?")) {
      cart = [];
      localStorage.setItem("cart", JSON.stringify(cart));
      renderCart();
    }
  });

  // أول تحميل للصفحة
  renderCart();
});
